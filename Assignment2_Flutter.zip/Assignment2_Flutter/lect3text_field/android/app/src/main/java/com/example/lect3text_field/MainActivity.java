package com.example.lect3text_field;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
